import React from 'react';
import './ListComponent.css';  // Importe o arquivo CSS

const ListComponent = ({ items }) => {
  return (
    <ul className="list-component">
      {items.map((item, index) => (
        <li key={index}>{item}</li>
      ))}
    </ul>
  );
};

export default ListComponent;
