import React from 'react';
import './Footer.css';  // Importe o arquivo CSS

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <p>© 2024 Mel Esmalteria</p>
        <p>Feito com 💅 por Melissa Fernanda Possani</p>
        <p>RA: 10482315215</p>
      </div>
    </footer>
  );
};

export default Footer;
