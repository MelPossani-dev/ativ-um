import React from 'react';
import './Header.css';  // Importe o arquivo CSS

const Header = () => {
  return (
    <header className="header">
      <h1>Mel Esmalteria</h1>
    </header>
  );
};

export default Header;
